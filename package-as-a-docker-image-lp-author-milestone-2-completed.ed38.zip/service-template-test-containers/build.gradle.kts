dependencies {

    implementation("org.testcontainers:testcontainers:$testContainersVersion")
    implementation("org.testcontainers:junit-jupiter:$testContainersVersion")
    implementation("org.testcontainers:mysql:$testContainersVersion")
    implementation("org.springframework.boot:spring-boot-starter-test")


}

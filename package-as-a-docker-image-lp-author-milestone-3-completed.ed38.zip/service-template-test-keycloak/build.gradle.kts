apply<RestAssuredDependenciesPlugin>()

dependencies {
    implementation("org.keycloak:keycloak-admin-client:12.0.1")
    implementation("org.springframework.boot:spring-boot-starter")
    implementation("org.springframework.boot:spring-boot-starter-test")


}

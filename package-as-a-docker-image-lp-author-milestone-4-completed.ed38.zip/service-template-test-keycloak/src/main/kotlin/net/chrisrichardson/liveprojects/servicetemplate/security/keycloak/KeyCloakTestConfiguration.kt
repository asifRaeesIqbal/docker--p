package net.chrisrichardson.liveprojects.servicetemplate.security.keycloak

import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.Configuration

@Configuration
@ComponentScan
class KeyCloakTestConfiguration {
}